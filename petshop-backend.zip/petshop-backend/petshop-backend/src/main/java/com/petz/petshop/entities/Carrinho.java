package com.petz.petshop.entities;

import jakarta.persistence.*;
import java.util.List;

@Entity
public class Carrinho {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

// UM CARRINHO PARA UM USUARIO
@OneToOne
@JoinColumn(name = "usuario_id")
private Usuario usuario;

// ITENS DO CARRINHO
@OneToMany(mappedBy = "carrinho", cascade = CascadeType.ALL)
private List<CarrinhoItem> itens;

public Long getId() {
    return id;
}

public Usuario getUsuario() {
    return usuario;
}

public void setUsuario(Usuario usuario) {
    this.usuario = usuario;
}

public List<CarrinhoItem> getItens() {
    return itens;
}

public void setItens(List<CarrinhoItem> itens) {
    this.itens = itens;
}


}
