package com.petz.petshop.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.petz.petshop.entities.CarrinhoItem;

public interface CarrinhoItemRepository extends JpaRepository<CarrinhoItem, Long> {

}