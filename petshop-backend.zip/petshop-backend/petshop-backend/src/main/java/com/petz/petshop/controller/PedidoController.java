package com.petz.petshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.petz.petshop.dto.PedidoDTO;
import com.petz.petshop.entities.Pedido;
import com.petz.petshop.repository.PedidoRepository;
import com.petz.petshop.service.PedidoService;

@RestController
@RequestMapping("/pedidos")
@CrossOrigin("*")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @Autowired
    private PedidoRepository pedidoRepository;

    @PostMapping
    public ResponseEntity<?> criarPedido(@RequestBody PedidoDTO dto) {

        return ResponseEntity.ok(pedidoService.salvar(dto));
    }

    @GetMapping
    public List<Pedido> listarTodos() {

        return pedidoRepository.findAll();
    }
}