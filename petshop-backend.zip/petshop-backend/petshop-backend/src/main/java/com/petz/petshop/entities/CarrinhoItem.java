package com.petz.petshop.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;

@Entity
public class CarrinhoItem {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private Long produtoId;

private Integer quantidade;

@ManyToOne
@JoinColumn(name = "carrinho_id")
@JsonIgnore
private Carrinho carrinho;

public Long getId() {
    return id;
}

public Long getProdutoId() {
    return produtoId;
}

public void setProdutoId(Long produtoId) {
    this.produtoId = produtoId;
}

public Integer getQuantidade() {
    return quantidade;
}

public void setQuantidade(Integer quantidade) {
    this.quantidade = quantidade;
}

public Carrinho getCarrinho() {
    return carrinho;
}

public void setCarrinho(Carrinho carrinho) {
    this.carrinho = carrinho;
}


}
