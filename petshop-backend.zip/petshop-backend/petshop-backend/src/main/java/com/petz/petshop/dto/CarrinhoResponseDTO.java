package com.petz.petshop.dto;

import java.util.List;

public class CarrinhoResponseDTO {

    private Long id;
    private Long usuarioId;
    private List<CarrinhoItemDTO> itens;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(Long usuarioId) {
        this.usuarioId = usuarioId;
    }

    public List<CarrinhoItemDTO> getItens() {
        return itens;
    }

    public void setItens(List<CarrinhoItemDTO> itens) {
        this.itens = itens;
    }
}