package com.petz.petshop.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.petz.petshop.dto.CarrinhoRequestDTO;
import com.petz.petshop.entities.*;
import com.petz.petshop.repository.*;

@RestController
@RequestMapping("/carrinho")
@CrossOrigin("*")
public class CarrinhoController {

    @Autowired
    private CarrinhoRepository carrinhoRepository;

    @Autowired
    private CarrinhoItemRepository itemRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @PostMapping("/adicionar")
    public Carrinho adicionar(@RequestBody CarrinhoRequestDTO request) {

        Carrinho carrinho = carrinhoRepository
                .findByUsuarioId(request.getUsuarioId())
                .orElseGet(() -> {

                    Carrinho novo = new Carrinho();

                    Usuario usuario = usuarioRepository
                            .findById(request.getUsuarioId())
                            .orElseThrow();

                    novo.setUsuario(usuario);
                    novo.setItens(new ArrayList<>());

                    return carrinhoRepository.save(novo);
                });

        CarrinhoItem item = new CarrinhoItem();

        item.setProdutoId(request.getProdutoId());
        item.setQuantidade(request.getQuantidade());

        item.setCarrinho(carrinho);

        itemRepository.save(item);

        carrinho.getItens().add(item);

        return carrinhoRepository.save(carrinho);
    }

    @GetMapping("/{usuarioId}")
    public Carrinho buscar(@PathVariable Long usuarioId) {

        return carrinhoRepository
                .findByUsuarioId(usuarioId)
                .orElse(null);
    }
}