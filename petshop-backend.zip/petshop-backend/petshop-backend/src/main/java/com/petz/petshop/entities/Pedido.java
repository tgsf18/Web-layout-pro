package com.petz.petshop.entities;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "pedidos")
public class Pedido {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;

private BigDecimal total;

private LocalDateTime dataPedido;

// RELACIONAMENTO COM USUARIO
@ManyToOne(fetch = FetchType.EAGER)
@JoinColumn(name = "usuario_id")
@JsonIgnoreProperties({"senha"})
private Usuario usuario;

// RELACIONAMENTO COM ITENS
@OneToMany(mappedBy = "pedido", cascade = CascadeType.ALL)
private List<PedidoItem> itens;

// GETTERS E SETTERS

public Long getId() {
    return id;
}

public BigDecimal getTotal() {
    return total;
}

public void setTotal(BigDecimal total) {
    this.total = total;
}

public LocalDateTime getDataPedido() {
    return dataPedido;
}

public void setDataPedido(LocalDateTime dataPedido) {
    this.dataPedido = dataPedido;
}

public Usuario getUsuario() {
    return usuario;
}

public void setUsuario(Usuario usuario) {
    this.usuario = usuario;
}

public List<PedidoItem> getItens() {
    return itens;
}

public void setItens(List<PedidoItem> itens) {
    this.itens = itens;
}

}