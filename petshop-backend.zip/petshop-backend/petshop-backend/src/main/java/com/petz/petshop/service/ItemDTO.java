package com.petz.petshop.service;

public class ItemDTO {

}
