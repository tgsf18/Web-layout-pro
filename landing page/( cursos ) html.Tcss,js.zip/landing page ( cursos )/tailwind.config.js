/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}"],
  theme: {
    extend: {
      colors: {
        // Criando a cor "musgo" personalizada
        'musgo': {
          'claro': '#4a5d23',
          'DEFAULT': '#2d3a10', // O tom principal
          'escuro': '#1a240a',
        },
      },
    },
  },
  plugins: [],
}