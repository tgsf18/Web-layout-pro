// shared.js - helper utilities for returnUrl handling

// Inicializa o namespace global
window.shared = window.shared || {};

function encodeReturnUrl() {
    try {
        return encodeURIComponent(window.location.href);
    } catch (e) {
        console.warn('encodeReturnUrl failed', e);
        return '';
    }
}

function isSafeUrl(url) {
    try {
        if (!url) return false;
        if (url.startsWith('/')) return true; // path-relative
        const u = new URL(url, window.location.origin);
        return /^https?:$/i.test(u.protocol);
    } catch (e) {
        return false;
    }
}

function setBackLinkFromReturnUrl(backLinkId = 'backLink', backLinkTextId = 'backLinkText') {
    try {
        const params = new URLSearchParams(window.location.search);
        const ret = params.get('returnUrl');
        const backLink = document.getElementById(backLinkId);
        const backLinkText = document.getElementById(backLinkTextId);
        if (!backLink) return;

        if (ret) {
            const decoded = decodeURIComponent(ret);
            if (isSafeUrl(decoded)) {
                backLink.setAttribute('href', decoded);
                if (backLinkText) backLinkText.innerText = 'Voltar para onde veio';
            } else {
                console.warn('returnUrl parece inseguro, ignorando:', decoded);
            }
            return;
        }

        // fallback to same-origin referrer
        if (document.referrer) {
            try {
                const ref = new URL(document.referrer);
                if (ref.origin === window.location.origin) {
                    backLink.setAttribute('href', document.referrer);
                    if (backLinkText) backLinkText.innerText = 'Voltar para onde veio';
                }
            } catch (e) {
                // ignore invalid referrer
            }
        }
    } catch (e) {
        console.warn('Erro ao configurar backLink:', e);
    }
}

// ===== Tema e Cores (Centralizado) =====
function initTheme() {
    // Padrão: light. Se 'dark', adiciona 'light-mode' (que é o tema escuro no CSS)
    const savedTheme = localStorage.getItem('petshop-theme') || 'light';
    if (savedTheme === 'dark') document.body.classList.add('light-mode');
    
    // Força a limpeza de qualquer cor de destaque antiga salva para evitar conflitos
    localStorage.removeItem('petshop-accent');

    // Garante a cor de destaque Laranja Pêssego Bem Forte
    document.documentElement.style.setProperty('--accent-rgb', '255, 120, 0');
    updateThemeIcon();
}

function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast fixed bottom-5 right-5 px-6 py-3 rounded-xl text-white text-sm font-bold z-[9999] ${
        type === 'success' ? 'bg-emerald-500' : 'bg-red-500'
    }`;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function toggleTheme() {
    document.body.classList.toggle('light-mode');
    const isDark = document.body.classList.contains('light-mode');
    localStorage.setItem('petshop-theme', isDark ? 'dark' : 'light');
    updateThemeIcon();
}

function updateThemeIcon() {
    // Atualiza ícones em desktop e mobile
    const isDark = document.body.classList.contains('light-mode');
    const icons = ['themeIcon', 'themeIconMobile'];
    
    icons.forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.setAttribute('data-lucide', isDark ? 'moon' : 'sun');
        }
    });

    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// Helper para verificar se o usuário está logado
function isLoggedIn() {
    return !!getUserFromStorage();
}

// ===== Profile Menu Component Helpers =====
function getUserFromStorage() {
    try {
        const s = localStorage.getItem('usuario');
        if (!s) return null;
        return JSON.parse(s);
    } catch (e) { 
        console.error("Erro ao parsear usuário do localStorage:", e);
        localStorage.removeItem('usuario'); // Limpa dados corrompidos
        return null; 
    }
}

function renderProfileMenu(targetSelector) {
    const target = document.querySelector(targetSelector);
    if (!target) return;
    const user = getUserFromStorage();
    const html = `
        ${user ? `
            <button id="profileBtn" class="flex items-center gap-3 p-1.5 rounded-full hover:bg-accent/10 transition-colors" aria-expanded="false" aria-controls="profileMenu">
                <div class="w-8 h-8 rounded-full bg-accent text-white flex items-center justify-center font-bold user-initials">U</div>
                <div class="hidden md:flex flex-col text-xs leading-tight text-left">
                    <span class="user-name font-bold">Usuário</span>
                    <span class="user-role text-[10px] uppercase opacity-60">ROLE</span>
                </div>
            </button>
            <div id="profileMenu" class="hidden absolute right-0 mt-2 w-44 rounded-xl shadow-xl py-2 z-[300]" style="background-color:var(--bg-card); color:var(--text-main); border:1px solid var(--border);">
                <button class="w-full text-left px-4 py-2 text-sm" style="color:var(--text-main);" onclick="openProfile()">Perfil</button>
                <button class="w-full text-left px-4 py-2 text-sm" style="color:var(--text-main);" onclick="openSettings()">Configurações</button>
                <div class="my-1" style="border-top:1px solid var(--border);"></div>
                <button class="w-full text-left px-4 py-2 text-sm text-rose-500" style="color:var(--rose-500, #ef4444);" onclick="logout()">Encerrar Sessão</button>
            </div>
        ` : `
            <div class="flex items-center gap-4">
                <button onclick="window.location.href='login.html'" class="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-accent hover:opacity-70 transition-all">
                    <i data-lucide="user" class="w-3 h-3"></i> Fazer Login
                </button>
                <a href="cadastro.html" class="hidden md:block text-[10px] font-bold uppercase tracking-widest text-gray-500 hover:text-accent transition-all">Criar Conta</a>
            </div>
        `}
    `;
    target.innerHTML = html;
}

function initProfileMenu(targetSelector) {
    const target = document.querySelector(targetSelector);
    if (!target) return;
    const user = getUserFromStorage();
    if (user) { // Only render profile menu if logged in
        if (!target.querySelector('#profileBtn')) renderProfileMenu(targetSelector); // Render if not already there
        const initials = (user.nome || user.email || 'U').split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase();
        const btn = target.querySelector('.user-initials'); if (btn) btn.innerText = initials;
        const nameEl = target.querySelector('.user-name'); if (nameEl) nameEl.innerText = user.nome || user.email || 'Usuário';
        const roleEl = target.querySelector('.user-role'); if (roleEl) roleEl.innerText = user.perfil || '';

        const profileBtn = target.querySelector('#profileBtn');
        const profileMenu = target.querySelector('#profileMenu');
        if (profileBtn && profileMenu) {
            profileBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const isHidden = profileMenu.classList.contains('hidden');
                if (isHidden) { profileMenu.classList.remove('hidden'); profileBtn.setAttribute('aria-expanded', 'true'); setTimeout(()=>document.addEventListener('click', close)); }
                else { profileMenu.classList.add('hidden'); profileBtn.setAttribute('aria-expanded', 'false'); }
            });

            function close(e) {
                if (!profileMenu.contains(e.target) && !profileBtn.contains(e.target)) {
                    profileMenu.classList.add('hidden'); profileBtn.setAttribute('aria-expanded', 'false'); document.removeEventListener('click', close);
                }
            }
        }
    } else { // Not logged in, render login button
        renderProfileMenu(targetSelector);
    }
}

function renderFooter(targetSelector) {
    const target = document.querySelector(targetSelector);
    if (!target) return;
    const year = new Date().getFullYear();
    const html = `
        <footer class="mt-auto border-t border-white/5 py-12" style="background-color: var(--bg-card);">
            <div class="container mx-auto px-6 md:px-10">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
                    <div class="md:col-span-2">
                        <div class="flex items-center gap-2 mb-6">
                            <div class="bg-accent p-2 rounded-[20px]">
                                <i data-lucide="dog" class="text-white w-6 h-6"></i>
                            </div>
                            <span class="text-2xl font-bold tracking-tight uppercase">TG<span class="text-accent">Petshop</span></span>
                        </div>
                        <p class="text-sm max-w-sm leading-relaxed" style="color: var(--text-muted);">
                            O seu pet center online completo. Qualidade premium em nutrição, acessórios e cuidados para quem você mais ama. Entrega rápida e CashPetz em todas as compras.
                        </p>
                    </div>
                    <div>
                        <h4 class="font-bold mb-6 text-xs uppercase tracking-[0.2em] text-accent">Links Rápidos</h4>
                        <ul class="space-y-4 text-sm" style="color: var(--text-main);">
                            <li><a href="index.html" class="hover:text-accent transition-colors flex items-center gap-2"><i data-lucide="home" class="w-4 h-4"></i> Início</a></li>
                            <li><a href="carrinho.html" class="hover:text-accent transition-colors flex items-center gap-2"><i data-lucide="shopping-bag" class="w-4 h-4"></i> Carrinho</a></li>
                            <li><a href="sobre.html" class="hover:text-accent transition-colors flex items-center gap-2"><i data-lucide="info" class="w-4 h-4"></i> Sobre Nós</a></li>
                            <li><a href="login.html" class="hover:text-accent transition-colors flex items-center gap-2"><i data-lucide="user" class="w-4 h-4"></i> Minha Conta</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 class="font-bold mb-6 text-xs uppercase tracking-[0.2em] text-accent">Contato</h4>
                        <ul class="space-y-4 text-sm" style="color: var(--text-muted);">
                            <li class="flex items-center gap-3"><i data-lucide="phone" class="w-4 h-4 text-accent"></i> (15) 3232-0000</li>
                            <li class="flex items-center gap-3"><i data-lucide="mail" class="w-4 h-4 text-accent"></i> contato@tgpetshop.com.br</li>
                            <li class="flex items-center gap-3"><i data-lucide="map-pin" class="w-4 h-4 text-accent"></i> Sorocaba, SP</li>
                        </ul>
                    </div>
                </div>
                <div class="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
                    <p class="text-xs" style="color: var(--text-muted);">© ${year} TG Petshop - Todos os direitos reservados. CNPJ: 00.000.000/0001-00</p>
                    <div class="flex gap-4">
                        <a href="#" class="p-2 rounded-xl bg-accent/5 hover:bg-accent/10 transition-all" style="color: var(--text-muted);"><i data-lucide="instagram" class="w-5 h-5"></i></a>
                        <a href="#" class="p-2 rounded-xl bg-accent/5 hover:bg-accent/10 transition-all" style="color: var(--text-muted);"><i data-lucide="facebook" class="w-5 h-5"></i></a>
                        <a href="#" class="p-2 rounded-xl bg-accent/5 hover:bg-accent/10 transition-all" style="color: var(--text-muted);"><i data-lucide="twitter" class="w-5 h-5"></i></a>
                    </div>
                </div>
            </div>
        </footer>
    `;
    target.innerHTML = html;
    if (typeof lucide !== 'undefined') lucide.createIcons();
}

// Expose as global for simple usage across pages
window.shared.initProfileMenu = initProfileMenu;
window.shared.renderProfileMenu = renderProfileMenu;
window.shared.getUserFromStorage = getUserFromStorage;
window.shared.toggleTheme = toggleTheme;
window.shared.initTheme = initTheme;
window.shared.isLoggedIn = isLoggedIn;
window.shared.showToast = showToast;
window.shared.setBackLinkFromReturnUrl = setBackLinkFromReturnUrl;
window.shared.initFooter = renderFooter;

/**
 * Bloqueia o acesso a páginas protegidas.
 * @param {string|null} requiredProfile - Perfil exigido (ex: 'ADMIN'). Se null, apenas exige login.
 */
window.shared.protectPage = function(requiredProfile = null) {
    const user = getUserFromStorage();
    if (!user) {
        // Salva a página atual para voltar após o login
        const returnUrl = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = `login.html?returnUrl=${returnUrl}`;
        return false;
    }
    if (requiredProfile && user.perfil !== requiredProfile) {
        window.location.href = 'index.html';
        return false;
    }
    return true;
};

// Global functions for older script references
window.logout = function() { 
    localStorage.removeItem('usuario'); 
    localStorage.removeItem('petshop-cart-local');
    window.dispatchEvent(new CustomEvent('cartUpdated', { detail: [] }));
    window.location.href = 'login.html'; 
};
window.showToast = showToast;
window.toggleTheme = toggleTheme;

// ===== Tecla ESC: fechar modais e dropdowns =====
function initEscHandler() {
    document.addEventListener('keydown', (e) => {
        if (!e || e.key !== 'Escape') return;

        // Fecha dropdown do perfil, se aberto
        try {
            const pm = document.getElementById('profileMenu');
            const pb = document.getElementById('profileBtn');
            if (pm && !pm.classList.contains('hidden')) {
                pm.classList.add('hidden');
                if (pb) pb.setAttribute('aria-expanded', 'false');
            }
        } catch (err) { /* ignore */ }

        // Fecha modais conhecidos
        ['profileModal', 'settingsModal', 'adminModal', 'productAdminModal'].forEach(id => {
            try {
                const m = document.getElementById(id);
                if (m && !m.classList.contains('hidden')) {
                    m.classList.add('hidden');
                    m.classList.remove('flex');
                }
            } catch (err) {}
        });

        // Fecha menu mobile, se aberto
        try {
            const mobileMenu = document.getElementById('mobileMenu');
            const overlay = document.getElementById('mobileOverlay');
            const hamburgerIcon = document.getElementById('hamburgerIcon');
            if (mobileMenu && mobileMenu.classList.contains('translate-x-0')) {
                mobileMenu.classList.remove('translate-x-0');
                mobileMenu.classList.add('translate-x-full');
                if (overlay) overlay.classList.add('hidden');
                if (hamburgerIcon) hamburgerIcon.setAttribute('data-lucide', 'menu');
                document.body.style.overflow = '';
                document.body.style.position = '';
                document.body.style.width = '';
            }
        } catch (err) {}
    });
}

window.shared.initEscHandler = initEscHandler;

// Animação de "Pata" ao clicar em adicionar
function triggerPawAnimation(element) {
    if (!element) return;
    
    const paw = document.createElement('div');
    paw.className = 'paw-animation';
    // Centraliza em relação ao botão
    paw.style.left = '50%';
    paw.style.top = '50%';
    paw.style.marginLeft = '-10px';
    paw.style.marginTop = '-10px';
    
    paw.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 11c-2 0-4 2-4 4 0 1.657 1.343 3 3 3s3-1.343 3-3c0-2-1-4-2-4zM6.5 7.5C7.328 6.672 8.5 6 9.5 6s2.172.672 3 .5S14 6 14 5.5 13 4 12 4 10 4 9.5 4 7.672 5.328 6.5 7.5zM18.5 7.5C19.328 6.672 20.5 6 21.5 6S23.672 6.672 24.5 7.5 26 9 25.5 9 23 8 21.5 8 19.672 8.328 18.5 7.5zM7 3C6 3 5 3.672 4.5 4.5S4 6.5 5 6.5 7 5 7 4.5 8 3 7 3z" /></svg>`;
    
    if (window.getComputedStyle(element).position === 'static') {
        element.style.position = 'relative';
    }
    
    element.appendChild(paw);
    setTimeout(() => paw.remove(), 800);
}
window.shared.triggerPawAnimation = triggerPawAnimation;

// Carrega automaticamente o cartBridge para expor helpers do carrinho em páginas que usam shared.js
(function(){
    try {
        const s = document.createElement('script');
        s.src = './js/cartBridge.js';
        s.defer = true;
        document.head.appendChild(s);
    } catch(e) { /* ignore */ }

    // Inicialização automática do tema para garantir consistência em todas as páginas
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => { if(window.shared.initTheme) window.shared.initTheme(); });
    } else {
        if(window.shared.initTheme) window.shared.initTheme();
    }
})();
