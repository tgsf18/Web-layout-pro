const CART_KEY = 'petshop_carrinho';

export function getCarrinho() {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
}

export function salvarCarrinho(carrinho) {
    localStorage.setItem(CART_KEY, JSON.stringify(carrinho));
    // Dispara evento para atualizar contadores na interface
    window.dispatchEvent(new CustomEvent('cartUpdated'));
}

export function adicionarProduto(produto) {
    const carrinho = getCarrinho();
    const itemExistente = carrinho.find(item => item.idProduto === produto.idProduto);

    if (itemExistente) {
        itemExistente.quantidade += 1;
    } else {
        carrinho.push({
            idProduto: produto.idProduto,
            nome: produto.nome,
            preco: produto.precoDesconto || produto.preco,
            imagem: produto.imagem,
            quantidade: 1
        });
    }
    salvarCarrinho(carrinho);
}

export function removerProduto(idProduto) {
    const carrinho = getCarrinho().filter(item => item.idProduto !== idProduto);
    salvarCarrinho(carrinho);
}

export function atualizarQuantidade(idProduto, novaQtd) {
    if (novaQtd < 1) return removerProduto(idProduto);
    
    const carrinho = getCarrinho();
    const item = carrinho.find(i => i.idProduto === idProduto);
    if (item) {
        item.quantidade = novaQtd;
        salvarCarrinho(carrinho);
    }
}

export function limparCarrinho() {
    localStorage.removeItem(CART_KEY);
    window.dispatchEvent(new CustomEvent('cartUpdated'));
}

export function calcularTotal() {
    return getCarrinho().reduce((acc, item) => acc + (item.preco * item.quantidade), 0);
}