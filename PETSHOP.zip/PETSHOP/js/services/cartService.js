const CART_KEY = 'petshop-cart-local';
const API_BASE = 'http://localhost:8081';

/**
 * Obtém o ID do usuário logado de forma segura
 */
function getLoggedUserId() {
    try {
        // Suporte para ambas as chaves de armazenamento
        const userJson = localStorage.getItem('usuarioLogado') || localStorage.getItem('usuario');
        if (!userJson) return null;
        
        const user = JSON.parse(userJson);
        // Tenta capturar o ID de diversas propriedades comuns (id, idUsuario, usuarioId)
        const id = user.id || user.idUsuario || user.usuarioId;
        
        if (id) console.log('[Usuário] ID recuperado com sucesso:', id);
        return id ? Number(id) : null;
    } catch (e) {
        console.error('[Usuário] Falha ao ler dados da sessão:', e);
        return null;
    }
}

export function getCart() {
    return JSON.parse(localStorage.getItem(CART_KEY)) || [];
}

export function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
    try {
        console.log('[Carrinho] Sincronizando interface com novo estado local');
        window.dispatchEvent(new CustomEvent('cartUpdated', { detail: cart }));
    } catch (e) { }
}

/**
 * Sincroniza o carrinho local com o servidor
 */
export async function carregarCarrinho() {
    const usuarioId = getLoggedUserId();
    if (!usuarioId) {
        saveCart([]);
        return [];
    }

    try {
        console.log(`[API] Buscando dados remotos: GET ${API_BASE}/carrinho/${usuarioId}`);
        const res = await fetch(`${API_BASE}/carrinho/${usuarioId}`);
        if (!res.ok) throw new Error('Erro ao buscar carrinho');
        
        const data = await res.json();
        const cartItems = data.itens || [];
        console.log('[Carrinho] Sincronização concluída. Itens:', cartItems.length);
        saveCart(cartItems);
        return cartItems;
    } catch (err) {
        console.error('[Carrinho] Erro na sincronização:', err);
        return getCart();
    }
}

export async function addToCart(produtoId, quantidade = 1) {
    const usuarioId = getLoggedUserId();

    console.log('[Carrinho] Iniciando fluxo de adição');
    console.log('[Usuário] ID:', usuarioId);
    console.log('[Produto] ID:', produtoId);
    
    if (!usuarioId) {
        console.warn('[Carrinho] Tentativa de adição bloqueada: Usuário não logado');
        if (window.shared?.showToast) {
            window.shared.showToast('Você precisa fazer login para adicionar itens ao carrinho.', 'error');
        } else {
            alert('Por favor, faça login para adicionar itens ao carrinho.');
        }
        return;
    }

    const body = {
        usuarioId: Number(usuarioId),
        produtoId: Number(produtoId),
        quantidade: Number(quantidade)
    };

    console.log('[API] Endpoint: POST http://localhost:8081/carrinho/adicionar');
    console.log('[API] Body enviado:', body);

    try {
        const response = await fetch(`${API_BASE}/carrinho/adicionar`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });

        if (!response.ok) {
            const errorMsg = await response.text();
            console.error('[API] Erro 400 ou superior retornado pelo servidor');
            console.error('[API] Status HTTP:', response.status);
            console.error('[API] Resposta do Backend:', errorMsg);
            console.error('[API] Body que causou o erro:', body);
            
            if (window.shared?.showToast) {
                window.shared.showToast(`Erro ${response.status}: ${errorMsg || 'Falha ao salvar no banco'}`, 'error');
            }
            return;
        }
        
        console.log('[API] Sucesso: Registro persistido no banco de dados');
        await carregarCarrinho();
        if (window.shared?.showToast) window.shared.showToast('Item adicionado ao seu carrinho! 🐾');
    } catch (err) {
        console.error('[API] Erro de rede ou conexão:', err);
        if (window.shared?.showToast) window.shared.showToast('Erro de conexão com o servidor.', 'error');
    }
}

export async function removeFromCart(itemId) {
    console.log('[Carrinho] Removendo item ID:', itemId);
    try {
        const response = await fetch(`${API_BASE}/carrinho/item/${itemId}`, {
            method: 'DELETE'
        });

        if (!response.ok) throw new Error('Erro ao remover');
        await carregarCarrinho();
    } catch (err) {
        if (window.shared?.showToast) window.shared.showToast('Erro ao remover item', 'error');
    }
}

export async function updateQuantity(itemId, quantidade) {
    if (quantidade < 1) return removeFromCart(itemId);
    console.log('[Carrinho] Atualizando quantidade item:', itemId, 'para:', quantidade);
    try {
        const response = await fetch(`${API_BASE}/carrinho/item/${itemId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ quantidade: Number(quantidade) })
        });
        if (!response.ok) throw new Error('Erro ao atualizar');
        await carregarCarrinho();
    } catch (err) {
        if (window.shared?.showToast) window.shared.showToast('Erro ao atualizar quantidade', 'error');
    }
}

export async function clearCart() {
    const usuarioId = getLoggedUserId();
    if (!usuarioId) { saveCart([]); return; }
    console.log('[Carrinho] Limpando carrinho para usuário:', usuarioId);
    try {
        await fetch(`${API_BASE}/carrinho/limpar/${usuarioId}`, { method: 'DELETE' });
        saveCart([]);
    } catch (err) {
        console.error('[API] Erro ao limpar carrinho no banco:', err);
        saveCart([]);
    }
}

export function getCartTotal() {
    const cart = getCart();
    // Nota: O backend deve retornar o preço no objeto do item ou produto
    return cart.reduce((total, item) => {
        const preco = item.preco || item.produto?.precoDesconto || item.produto?.preco || 0;
        return total + (preco * (item.quantidade || 0));
    }, 0);
}

// Propaga alterações vindas de outras abas
window.addEventListener('storage', (e) => {
    if (e.key === CART_KEY) {
        const cart = JSON.parse(e.newValue || '[]');
        try { window.dispatchEvent(new CustomEvent('cartUpdated', { detail: cart })); } catch(e){}
    }
});
