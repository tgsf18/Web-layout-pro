import { getCart } from './services/cartService.js';

function findHeaderBadges() {
    const badges = [];
    document.querySelectorAll('i[data-lucide="shopping-cart"]').forEach(icon => {
        const badge = icon.parentElement.querySelector('span');
        if (badge) badges.push(badge);
    });
    // mobile link text showing "0 itens"
    const mobileLink = Array.from(document.querySelectorAll('a, span')).find(el => /Carrinho/i.test(el.textContent) && /itens/i.test((el.innerText||'') ));
    return { badges, mobileLink };
}

function updateBadges() {
    const cart = getCart();
    const { badges, mobileLink } = findHeaderBadges();
    const count = cart.reduce((s, it) => s + (it.quantidade || 0), 0);
    badges.forEach(b => b.innerText = count);
    if (mobileLink) {
        const text = mobileLink.innerText.replace(/\d+ itens?/i, `${count} itens`);
        mobileLink.innerText = text.includes('itens') ? text : `${mobileLink.innerText} ${count} itens`;
    }
}

window.addEventListener('cartUpdated', updateBadges);
window.addEventListener('storage', (e) => { if (e.key === 'petshop-cart-local') updateBadges(); });

document.addEventListener('DOMContentLoaded', updateBadges);
