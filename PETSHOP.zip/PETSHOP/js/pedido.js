import { getCart, getCartTotal, clearCart, carregarCarrinho } from './services/cartService.js';
import { criarPedido } from './api.js';

export async function finalizarCompra() {
    const carrinho = getCart();
    
    if (carrinho.length === 0) {
        alert('Seu carrinho está vazio!');
        return;
    }

    const usuarioSessao = JSON.parse(localStorage.getItem('usuario') || 'null');
    
    if (!usuarioSessao) {
        alert('Você precisa estar logado para finalizar a compra!');
        window.location.href = 'login.html';
        return;
    }

    // Mapeia para o formato esperado pelo PedidoDTO do Backend
    const pedidoDTO = {
        // Enviamos o ID dentro de um objeto 'usuario' para facilitar o vínculo no JPA
        usuario: { 
            // Tenta pegar id ou idUsuario, dependendo de como o seu backend devolve no login
            id: usuarioSessao.id || usuarioSessao.idUsuario
        },
        total: getCartTotal(),
        itens: carrinho.map(item => ({
            produtoId: item.produtoId || item.produto?.idProduto,
            quantidade: item.quantidade,
            subtotal: (item.preco || item.produto?.precoDesconto || 0) * item.quantidade
        }))
    };

    try {
        const btn = document.getElementById('btnFinalizar');
        if(btn) { btn.disabled = true; btn.innerText = 'Processando...'; }

        const resultado = await criarPedido(pedidoDTO);
        
        // === Lógica de Atualização de Estoque ===
        // Para cada item comprado, buscamos o produto e diminuímos o estoque via API
        for (const item of carrinho) {
            try {
                // 1. Busca os dados atuais do produto para pegar o estoque real do banco
                const resProd = await fetch(`http://localhost:8081/api/produtos/${item.idProduto}`);
                if (resProd.ok) {
                    const produtoData = await resProd.json();
                    
                    // 2. Calcula o novo estoque (garantindo que não seja negativo)
                    const novoEstoque = Math.max(0, (produtoData.qtdEstoque || 0) - item.quantidade);
                    
                    // 3. Envia o comando de atualização (PUT) para o servidor
                    await fetch(`http://localhost:8081/api/produtos/${item.idProduto}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            ...produtoData,
                            qtdEstoque: novoEstoque
                        })
                    });
                }
            } catch (err) {
                console.error(`Erro ao atualizar estoque do produto ${item.idProduto}:`, err);
            }
        }

        alert('Pedido realizado com sucesso! Número do pedido: ' + (resultado.idPedido || 'Confirmado'));
        await clearCart();
        await carregarCarrinho(); // Sincroniza estado vazio
        window.location.href = 'index.html';
        
    } catch (error) {
        alert('Erro ao finalizar pedido. Tente novamente mais tarde.');
    } finally {
        const btn = document.getElementById('btnFinalizar');
        if(btn) { btn.disabled = false; btn.innerText = 'Finalizar Compra'; }
    }
}