(async function(){
    try {
        const cs = await import('./services/cartService.js');

        window.addToCart = function(arg) {
            // Garante que pegamos o idProduto correto
            const idProduto = typeof arg === 'object' ? (arg.idProduto || arg.id) : arg;
            cs.addToCart(idProduto);
        };

        window.removeFromCart = cs.removeFromCart;
        window.clearCart = cs.clearCart;
        window.getCart = cs.getCart;
        window.getCartTotal = cs.getCartTotal;
    } catch (e) {
        console.error('Erro ao inicializar cartBridge', e);
    }
})();
