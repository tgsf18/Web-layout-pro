const BASE_URL = 'http://localhost:8081';

export async function buscarProdutos() {
    try {
        const response = await fetch(`${BASE_URL}/produtos`);
        if (!response.ok) throw new Error('Erro ao buscar produtos');
        return await response.json();
    } catch (error) {
        console.error('API Error (buscarProdutos):', error);
        return [];
    }
}

export async function buscarPedidos() {
    try {
        const response = await fetch(`${BASE_URL}/pedidos`);
        if (!response.ok) throw new Error('Erro ao buscar pedidos');
        return await response.json();
    } catch (error) {
        console.error('API Error (buscarPedidos):', error);
        return [];
    }
}

export async function criarPedido(pedidoDTO) {
    try {
        const response = await fetch(`${BASE_URL}/pedidos`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(pedidoDTO)
        });
        
        if (!response.ok) throw new Error('Erro ao processar pedido no servidor');
        return await response.json();
    } catch (error) {
        console.error('API Error (criarPedido):', error);
        throw error;
    }
}