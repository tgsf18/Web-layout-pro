import { buscarProdutos } from './api.js';
import { adicionarProduto } from './storage.js';

const container = document.getElementById('productGrid');

async function renderizarProdutos() {
    if (!container) return;
    
    // Renderizar Skeleton Screen (Exibe 4 cards de carregamento)
    container.innerHTML = Array(4).fill(0).map(() => `
        <div class="glass-card p-5 flex flex-col justify-between">
            <div class="mb-4 rounded-2xl aspect-square skeleton"></div>
            <div>
                <div class="skeleton h-6 w-3/4 mb-2 rounded-lg"></div>
                <div class="skeleton h-3 w-full mb-1 rounded-lg"></div>
                <div class="skeleton h-3 w-2/3 mb-4 rounded-lg"></div>
            </div>
            <div class="flex items-center justify-between">
                <div class="skeleton h-8 w-1/3 rounded-lg"></div>
                <div class="skeleton h-10 w-10 rounded-xl"></div>
            </div>
        </div>
    `).join('');
    
    const produtos = await buscarProdutos();
    container.innerHTML = '';

    if (produtos.length === 0) {
        container.innerHTML = '<p class="col-span-full text-center text-gray-500">Nenhum produto disponível no momento.</p>';
        return;
    }

    produtos.forEach(produto => {
        const card = document.createElement('div');
        card.className = 'glass-card p-5 product-card group flex flex-col justify-between';
        card.innerHTML = `
            <div class="relative mb-4 overflow-hidden rounded-2xl bg-gray-100 aspect-square flex items-center justify-center">
                <img src="${produto.imagem || 'assets/img/placeholder.png'}" class="max-h-40 object-contain group-hover:scale-110 transition-transform">
            </div>
            <div>
                <h3 class="font-bold text-lg mb-1">${produto.nome}</h3>
                <p class="text-xs text-gray-500 line-clamp-2 mb-4">${produto.descricao || 'Qualidade garantida para seu pet.'}</p>
            </div>
            <div class="flex items-center justify-between">
                <span class="text-xl font-black text-accent price-font">R$ ${produto.preco.toFixed(2)}</span>
                <button class="add-to-cart-btn bg-accent text-white p-3 rounded-xl hover:shadow-lg transition-all ${!window.shared.isLoggedIn() ? 'opacity-50 cursor-not-allowed' : ''}" 
                        data-id="${produto.idProduto}"
                        ${!window.shared.isLoggedIn() ? 'disabled title="Faça login para adicionar ao carrinho"' : ''}
                        >
                    <i data-lucide="plus"></i>
                </button>
            </div>
        `;

        card.querySelector('.add-to-cart-btn').addEventListener('click', (e) => {
            adicionarProduto(produto);
            if (!window.shared.isLoggedIn()) {
                window.showToast('Faça login para adicionar produtos ao carrinho.', 'error');
                return;
            }
            if (window.shared && window.shared.triggerPawAnimation) {
                window.shared.triggerPawAnimation(e.currentTarget);
            }
            alert(`${produto.nome} adicionado ao carrinho! ✅`);
        });

        container.appendChild(card);
    });
    if (window.lucide) lucide.createIcons();
}

document.addEventListener('DOMContentLoaded', renderizarProdutos);