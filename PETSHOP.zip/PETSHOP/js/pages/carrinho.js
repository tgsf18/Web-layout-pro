import {
    getCart,
    removeFromCart,
    getCartTotal,
    clearCart
} from '../services/cartService.js';

function renderCart() {
    const cart = getCart();
    const container = document.getElementById('cart-items');
    container.innerHTML = '';

    cart.forEach(item => {
        container.innerHTML += `
            <div class="bg-white p-4 rounded-xl shadow mb-4 flex justify-between">
                <div>
                    <h2 class="text-xl font-bold">${item.nome}</h2>
                    <p>Quantidade: ${item.quantidade}</p>
                    <p>R$ ${item.preco}</p>
                </div>
                <button onclick="remover(${item.id})" class="bg-red-500 text-white px-4 py-2 rounded-lg">Remover</button>
            </div>
        `;
    });

    const totalEl = document.getElementById('cart-total');
    if (totalEl) totalEl.innerText = getCartTotal().toFixed(2);
}

window.remover = function(id) {
    removeFromCart(id);
    renderCart();
}

window.finalizarCompra = function() {
    // Sem backend configurado aqui; apenas limpa o carrinho e redireciona.
    clearCart();
    alert('Compra finalizada (modo offline). Obrigado!');
    window.location.href = 'index.html';
}

document.addEventListener('cartUpdated', () => renderCart());

renderCart();
