import { addToCart } from '../services/cartService.js';

const API = 'http://localhost:8081';

async function carregarProdutos() {
    try {
        const response = await fetch(`${API}/produtos`);
        const produtos = await response.json();
        const container = document.getElementById('products');

        produtos.forEach(produto => {
            container.innerHTML += `
                <div class="bg-white rounded-xl shadow p-4">
                    <img src="${produto.imagem}" class="w-full h-48 object-cover rounded-lg">
                    <h2 class="text-xl font-bold mt-2">${produto.nome}</h2>
                    <p class="text-green-600 font-bold">R$ ${produto.preco}</p>
                    <button class="bg-blue-500 text-white px-4 py-2 rounded-lg mt-4 w-full" onclick="adicionar(${produto.id})">Adicionar ao Carrinho</button>
                </div>
            `;
        });

        window.produtos = produtos;
    } catch (e) {
        console.warn('Não foi possível carregar produtos do backend:', e);
    }
}

window.adicionar = function(id) {
    const produto = window.produtos ? window.produtos.find(p => p.id === id) : null;
    if (produto) {
        addToCart(produto);
        alert('Produto adicionado');
    } else {
        // fallback mínimo
        addToCart({ id, nome: 'Produto', preco: 0, imagem: '' });
        alert('Produto adicionado (offline)');
    }
}

carregarProdutos();
